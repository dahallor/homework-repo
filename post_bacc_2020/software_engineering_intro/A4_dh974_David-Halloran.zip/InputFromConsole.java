import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InputFromConsole implements Input {

	ScannerWrapper scannerWrapper;
	SystemWrapper systemWrapper;

	public InputFromConsole(ScannerWrapper scannerWrapper, SystemWrapper systemWrapper) {
		this.scannerWrapper = scannerWrapper;
		this.systemWrapper = systemWrapper;
	}

	@Override
	@SuppressWarnings("null")
	public List<String> read() throws IOException {
		List<String> txtList = new ArrayList<String>();
		String txtString = "";
		systemWrapper.println("Please enter lines to add, then enter -1 to finish:");
		int stop = 0;

		do {
			txtString = scannerWrapper.nextLine();
			if (txtString.compareTo("-1") == 0) {
				stop = Integer.parseInt(txtString);
				continue;
			}
			txtList.add(txtString);
		} while (stop != -1);

		return txtList;
	}

}