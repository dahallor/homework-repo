import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class InputFromFile implements Input {

	public static Scanner txtScanner;
	public static List<String> txtList;
	public String txtInput = "";

	@Override
	public List<String> read() throws IOException {

		File kwic = new File("kwic.txt");
		txtScanner = new Scanner(kwic);
		txtList = Files.readAllLines(Paths.get("kwic.txt"));

		return txtList;
	}
}
