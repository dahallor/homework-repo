public class OutputFactory {

	SystemWrapper systemWrapper;

	public OutputFactory(SystemWrapper systemWrapper) {
		this.systemWrapper = systemWrapper;
	}

	public enum OutputType {
		FILE {
			@Override
			public Output getInstance(SystemWrapper systemWrapper) {
				return new OutputToFile();

			}
		},
		CONSOLE {
			@Override
			public Output getInstance(SystemWrapper systemWrapper) {
				return new OutputToConsole(systemWrapper);
			}
		};

		public abstract Output getInstance(SystemWrapper systemWrapper);
	}

	public Output create(String choice) throws IllegalArgumentException {
		OutputType type = OutputType.valueOf(choice);
		return type.getInstance(systemWrapper);

	}
}
