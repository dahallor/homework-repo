import java.io.IOException;
import java.util.List;

public class MasterControl {

	public static void main(String[] args) throws IOException {
		MasterControl masterControl = new MasterControl();
		ScannerWrapper scannerWrapper = ScannerWrapper.getInstance();
		SystemWrapper systemWrapper = SystemWrapper.getInstance();
		masterControl.start(scannerWrapper, systemWrapper);

	}

	@SuppressWarnings({ "unused" })
	public void start(ScannerWrapper scannerWrapper, SystemWrapper systemWrapper) throws IOException {

		systemWrapper.println("Please enter FILE to input from file or CONSOLE to input from console:");
		String inputScanString = scannerWrapper.nextLine();
		systemWrapper.println("Please enter FILE to output from file or CONSOLE to output from console:");
		String outputScanString = scannerWrapper.nextLine();

		List<String> inputResults;
		List<String> shifterResults;
		List<String> alphabetResults;

		InputFactory inputFactory = new InputFactory(scannerWrapper, systemWrapper);
		CircularShifter shift = new CircularShifter();
		Alphabetizer abc = new Alphabetizer();
		OutputFactory outputFactory = new OutputFactory(systemWrapper);

		Input input = inputFactory.create(inputScanString);
		inputResults = input.read();
		shifterResults = shift.shiftLines(inputResults);
		alphabetResults = abc.sort(shifterResults);
		Output output = outputFactory.create(outputScanString);
		output.write(alphabetResults);

	}
}
