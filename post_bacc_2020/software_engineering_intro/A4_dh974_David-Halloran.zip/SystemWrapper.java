import java.io.IOException;

public class SystemWrapper {
	@SuppressWarnings("unused")
	private static final SystemWrapper systemwrapper = new SystemWrapper();

	private SystemWrapper() {

	}

	public static SystemWrapper getInstance() throws IOException {
		SystemWrapper systemwrapper = new SystemWrapper();
		return systemwrapper;
	}

	public void println(String output) {
		System.out.println(output);

	}

}
