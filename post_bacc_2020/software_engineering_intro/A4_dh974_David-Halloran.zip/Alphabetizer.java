import java.io.IOException;
import java.util.List;

public class Alphabetizer {

	public List<String> sort(List<String> lines) throws IOException {

		String currentTempValue = new String();
		List<String> shiftResults = lines;
		int listSize = shiftResults.size();

		String shiftArray[] = shiftResults.toArray(new String[0]);

		for (int i = 0; i < listSize; i++) {
			for (int j = i + 1; j < listSize; j++) {
				if (shiftArray[i].compareToIgnoreCase(shiftArray[j]) > 0) {
					currentTempValue = shiftArray[i];
					shiftArray[i] = shiftArray[j];
					shiftArray[j] = currentTempValue;
				}
			}
		}

		lines.clear();
		for (int i = 0; i < listSize; i++) {
			lines.add(shiftArray[i]);
		}
		return lines;
	}

}
