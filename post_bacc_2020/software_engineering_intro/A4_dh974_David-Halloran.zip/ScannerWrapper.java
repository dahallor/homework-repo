import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScannerWrapper {
	@SuppressWarnings("unused")
	private static final ScannerWrapper scannerwrapper = new ScannerWrapper();

	private ScannerWrapper() {

	}

	public static ScannerWrapper getInstance() throws IOException {
		ScannerWrapper scannerwrapper = new ScannerWrapper();
		return scannerwrapper;
	}

	List<String> txtInput = new ArrayList<String>();
	Scanner scan = new Scanner(System.in);

	public String nextLine() throws IOException {
		String input = "";

		if (scan.hasNextLine()) {
			input = scan.nextLine();
		}
		return input;
	}

	public void closeScanner() throws IOException {
		ScannerWrapper s = ScannerWrapper.getInstance();
		s.scan.close();
	}
}
