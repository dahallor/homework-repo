
public class Warrior {

	int level;
	static int attack;
	static int defense;

	public Warrior() {

	}

	public int getLevel() {
		return level;
	}

	public int getAttack() {
		return attack;
	}

	public int getDefense() {
		return defense;
	}

	public static void getMessage(String value) {
		if (value == "level") {
			System.out.println("Level must be greater than 0.");
		}
		if (value == "attack") {
			System.out.println("Attack must be greater than 0.");
		}
		if (value == "defense") {
			System.out.println("Defense must be greater than 0.");
		}
	}
}
