
public class AggressiveWarrior extends Warrior {

	static Warrior warrior;

	public AggressiveWarrior(int level) {
		this.level = level;
	}

	public static class Builder extends WarriorBuilder {
		AggressiveWarrior aggressiveWarrior;

		public Builder(int level) {
			aggressiveWarrior = new AggressiveWarrior(level);
			aggressiveWarrior.attack = 3;
			aggressiveWarrior.defense = 2;
		}

		public Builder attack(int attack) {
			this.attack = attack;
			aggressiveWarrior.attack = attack;
			return this;
		}

		public Builder defense(int defense) {
			this.defense = defense;
			aggressiveWarrior.defense = defense;
			return this;
		}

		public Warrior build() {
			validate(aggressiveWarrior);
			return aggressiveWarrior;
		}

		public void validate(AggressiveWarrior aggressiveWarrior) {

			if (aggressiveWarrior.level < 0 && aggressiveWarrior.attack < 0 && aggressiveWarrior.defense < 0) {
				throw new IllegalStateException(
						"Level must be greater than 0. Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (aggressiveWarrior.level < 0 && aggressiveWarrior.attack < 0 && aggressiveWarrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. Attack must be greater than 0. ");
			}
			if (aggressiveWarrior.level < 0 && aggressiveWarrior.attack > 0 && aggressiveWarrior.defense < 0) {
				throw new IllegalStateException("Level must be greater than 0. Defense must be greater than 0. ");
			}
			if (aggressiveWarrior.level > 0 && aggressiveWarrior.attack < 0 && aggressiveWarrior.defense < 0) {
				throw new IllegalStateException("Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (aggressiveWarrior.level < 0 && aggressiveWarrior.attack > 0 && aggressiveWarrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. ");
			}
			if (aggressiveWarrior.level > 0 && aggressiveWarrior.attack < 0 && aggressiveWarrior.defense > 0) {
				throw new IllegalStateException("Attack must be greater than 0. ");
			}
			if (aggressiveWarrior.level > 0 && aggressiveWarrior.attack > 0 && aggressiveWarrior.defense < 0) {
				throw new IllegalStateException("Defense must be greater than 0. ");
			}
		}

	}
}
