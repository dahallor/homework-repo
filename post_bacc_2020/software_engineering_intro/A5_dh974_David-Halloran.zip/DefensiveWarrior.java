
public class DefensiveWarrior extends Warrior {

	static Warrior warrior;

	public DefensiveWarrior(int level) {
		this.level = level;
	}

	public static class Builder extends WarriorBuilder {
		DefensiveWarrior defensiveWarrior;

		public Builder(int level) {
			defensiveWarrior = new DefensiveWarrior(level);
			defensiveWarrior.attack = 2;
			defensiveWarrior.defense = 3;
		}

		public Builder attack(int attack) {
			this.attack = attack;
			defensiveWarrior.attack = attack;
			return this;
		}

		public Builder defense(int defense) {
			this.defense = defense;
			defensiveWarrior.defense = defense;
			return this;
		}

		public Warrior build() {
			validate(defensiveWarrior);
			return defensiveWarrior;
		}

		public void validate(DefensiveWarrior defensiveWariior) {

			if (defensiveWarrior.level < 0 && defensiveWarrior.attack < 0 && defensiveWarrior.defense < 0) {
				throw new IllegalStateException(
						"Level must be greater than 0. Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (defensiveWarrior.level < 0 && defensiveWarrior.attack < 0 && defensiveWarrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. Attack must be greater than 0. ");
			}
			if (defensiveWarrior.level < 0 && defensiveWarrior.attack > 0 && defensiveWarrior.defense < 0) {
				throw new IllegalStateException("Level must be greater than 0. Defense must be greater than 0. ");
			}
			if (defensiveWarrior.level > 0 && defensiveWarrior.attack < 0 && defensiveWarrior.defense < 0) {
				throw new IllegalStateException("Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (defensiveWarrior.level < 0 && defensiveWarrior.attack > 0 && defensiveWarrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. ");
			}
			if (defensiveWarrior.level > 0 && defensiveWarrior.attack < 0 && defensiveWarrior.defense > 0) {
				throw new IllegalStateException("Attack must be greater than 0. ");
			}
			if (defensiveWarrior.level > 0 && defensiveWarrior.attack > 0 && defensiveWarrior.defense < 0) {
				throw new IllegalStateException("Defense must be greater than 0. ");
			}
		}
	}
}
