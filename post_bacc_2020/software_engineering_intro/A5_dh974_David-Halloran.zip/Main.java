
public class Main {

	public static void main(String[] args) {
		Warrior warrior1 = new AggressiveWarrior.Builder(1).build();
		System.out.println("Aggresive: " + warrior1.level + " " + warrior1.attack + " " + warrior1.defense);
		Warrior warrior2 = new DefensiveWarrior.Builder(1).build();
		System.out.println("Defensive: " + warrior2.level + " " + warrior2.attack + " " + warrior2.defense);

	}
}
