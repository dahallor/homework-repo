
public abstract class WarriorBuilder {
	int level;
	int attack;
	int defense;

}
