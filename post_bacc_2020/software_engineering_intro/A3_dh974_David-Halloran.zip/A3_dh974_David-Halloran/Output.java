
public interface Output {
	public default void write() {

	}
}
