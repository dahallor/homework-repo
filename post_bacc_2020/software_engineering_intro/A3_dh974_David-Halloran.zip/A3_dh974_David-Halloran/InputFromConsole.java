import java.io.IOException;
import java.util.List;

public class InputFromConsole implements Input {

	ScannerWrapper scannerWrapper;
	SystemWrapper systemWrapper;

	public InputFromConsole(ScannerWrapper scannerWrapper, SystemWrapper systemWrapper) {
		this.scannerWrapper = scannerWrapper;
		this.systemWrapper = systemWrapper;
	}

	public static List<String> read(ScannerWrapper scannerWrapper, SystemWrapper systemWrapper) throws IOException {

		List<String> txtList;
		String txtString = "";
		systemWrapper.println("Hello, please enter lines to add. Enter -1 to quit");
		int stop = 0;

		do {
			txtString = scannerWrapper.nextLine();
			if (txtString.compareTo("-1") == 0) {
				stop = Integer.parseInt(txtString);
			}
		} while (stop != -1);

		txtList = scannerWrapper.getSavedList();

		return txtList;
	}

}