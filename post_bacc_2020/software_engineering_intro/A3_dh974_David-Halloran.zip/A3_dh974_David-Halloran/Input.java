import java.io.IOException;

public interface Input {
	public static void read() throws IOException {

	}
}
