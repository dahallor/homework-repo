import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScannerWrapper {
	private static ScannerWrapper scannerwrapper = new ScannerWrapper();

	private ScannerWrapper() {

	}

	static List<String> txtInput = new ArrayList<String>();

	public static ScannerWrapper getInstance() throws IOException {

		return scannerwrapper;
	}

	static Scanner scan = new Scanner(System.in);

	public String nextLine() {
		String input = "";

		if (scan.hasNextLine()) {
			input = scan.nextLine();
			if (input.equals("FILE") == false && input.equals("CONSOLE") == false && input.equals("-1") == false) {
				ScannerWrapper.setSavedList(input);
			}
		}

		return input;
	}

	private static void setSavedList(String input) {
		txtInput.add(input);
	}

	public List<String> getSavedList() {
		return txtInput;

	}

	public static void closeScanner() {
		scan.close();
	}
}
