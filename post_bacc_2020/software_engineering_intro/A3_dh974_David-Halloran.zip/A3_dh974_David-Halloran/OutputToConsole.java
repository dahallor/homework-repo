import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OutputToConsole implements Output {

	SystemWrapper systemWrapper;

	public OutputToConsole(SystemWrapper systemWrapper) {
		this.systemWrapper = systemWrapper;
	}

	public static void write(List<String> lines, SystemWrapper systemWrapper) throws IOException {

		String output;
		Alphabetizer sortedResults = new Alphabetizer();
		List<String> alphabetizerResults = new ArrayList<String>();

		alphabetizerResults = sortedResults.sort(lines);
		int size = alphabetizerResults.size();
		for (int i = 0; i < size; i++) {
			output = alphabetizerResults.get(i);
			// OutputToConsole.write(lines);
			systemWrapper.println(output);
		}

	}

}
