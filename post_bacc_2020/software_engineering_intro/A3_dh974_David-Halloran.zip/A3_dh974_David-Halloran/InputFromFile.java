import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class InputFromFile {

	public static Scanner txtScanner;
	public static List<String> txtList;
	public String txtInput = "";

	public static List<String> read() throws IOException {

		File kwic = new File("C:\\Users\\bonem\\Desktop\\Class\\Intro to Software Engineering\\kwic.txt");
		txtScanner = new Scanner(kwic);
		txtList = Files
				.readAllLines(Paths.get("C:\\Users\\bonem\\Desktop\\Class\\Intro to Software Engineering\\kwic.txt"));

		return txtList;
	}
}
