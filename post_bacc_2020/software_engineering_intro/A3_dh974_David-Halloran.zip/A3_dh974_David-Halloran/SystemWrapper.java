import java.io.IOException;

public class SystemWrapper {
	private static SystemWrapper systemwrapper = new SystemWrapper();

	private SystemWrapper() {

	}

	public static SystemWrapper getInstance() throws IOException {

		return systemwrapper;
	}

	public void println(String output) {
		System.out.println(output);

	}

}
