import java.io.IOException;
import java.util.List;

public class MasterControl {

	public static void main(String[] args) throws IOException {
		MasterControl masterControl = new MasterControl();
		ScannerWrapper scannerWrapper = ScannerWrapper.getInstance();
		SystemWrapper systemWrapper = SystemWrapper.getInstance();
		masterControl.start(scannerWrapper, systemWrapper);

	}

	@SuppressWarnings({ "unused" })
	public void start(ScannerWrapper scannerWrapper, SystemWrapper systemWrapper) throws IOException {

		systemWrapper.println("Please enter FILE to input from file or CONSOLE to input from console:");
		String inputScanString = scannerWrapper.nextLine();

		systemWrapper.println("Please enter FILE to output from file or CONSOLE to output from console:");
		String outputScanString = scannerWrapper.nextLine();

		List<String> inputResults = null;
		List<String> shifterResults;
		List<String> alphabetResults;

		CircularShifter shift = new CircularShifter();
		Alphabetizer abc = new Alphabetizer();

		if (inputScanString.equals("FILE")) {
			InputFromFile inputFile = new InputFromFile();
			inputResults = InputFromFile.read();
		}
		if (inputScanString.equals("CONSOLE")) {
			InputFromConsole inputConsole = new InputFromConsole(scannerWrapper, systemWrapper);
			inputResults = InputFromConsole.read(scannerWrapper, systemWrapper);
		}

		shifterResults = shift.shiftLines(inputResults);
		alphabetResults = abc.sort(shifterResults);

		if (outputScanString.equals("FILE")) {
			OutputToFile outputFile = new OutputToFile();
			OutputToFile.write(alphabetResults);
		}
		if (outputScanString.equals("CONSOLE")) {
			OutputToConsole outputConsole = new OutputToConsole(systemWrapper);
			OutputToConsole.write(alphabetResults, systemWrapper);
		}

	}

}
