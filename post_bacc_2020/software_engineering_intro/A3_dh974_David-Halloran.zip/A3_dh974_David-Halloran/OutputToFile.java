
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class OutputToFile {

	public static void write(List<String> lines) throws IOException {
		BufferedWriter txtOutput = new BufferedWriter(
				new FileWriter("C:\\Users\\bonem\\Desktop\\Class\\Intro to Software Engineering\\kwic_output.txt"));
		String toWrite = "";

		int i = 0;
		int size = lines.size();

		while (i < size) {
			toWrite = lines.get(i);
			txtOutput.write(toWrite + "\n");
			i++;
		}
		txtOutput.close();

	}

}