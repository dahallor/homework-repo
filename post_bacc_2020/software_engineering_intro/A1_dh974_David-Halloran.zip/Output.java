import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Output {

	public void write(List<String> lines) throws IOException {
		BufferedWriter txtOutput = new BufferedWriter(
				new FileWriter("C:\\Users\\bonem\\Desktop\\Class\\Intro to Software Engineering\\kwic_output.txt"));
		Alphabetizer sortedResults = new Alphabetizer();
		List<String> alphabetizerResults = new ArrayList<String>();
		String toWrite = "";

		alphabetizerResults = sortedResults.sort(lines);
		int i = 0;
		int size = alphabetizerResults.size();

		while (i < size) {
			toWrite = alphabetizerResults.get(i);
			txtOutput.write(toWrite);
			i++;
		}

		txtOutput.close();

	}

}
