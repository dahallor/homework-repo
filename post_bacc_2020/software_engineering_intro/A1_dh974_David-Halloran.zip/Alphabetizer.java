import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Alphabetizer {

	public List<String> sort(List<String> lines) throws IOException {
		List<String> shiftResults = new ArrayList<String>();
		String currentTempValue = new String();

		int listSize = shiftResults.size();
		String shiftArray[];

		CircularShifter results = new CircularShifter();
		shiftResults = results.shiftLines(lines);

		shiftArray = (String[]) (shiftResults.toArray());

		for (int i = 0; i < listSize; i++) {
			for (int j = i + 1; j < listSize; j++) {
				if (shiftArray[i].compareTo(shiftArray[j]) > 0) {
					currentTempValue = shiftArray[i];
					shiftArray[i] = shiftArray[j];
					shiftArray[j] = currentTempValue;

				}

			}

		}

		for (int i = 0; i < listSize; i++) {
			lines.add(shiftArray[i]);
		}

		return lines;
	}

}
