import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CircularShifter {

	public List<String> shiftLines(List<String> lines) throws IOException {
		Input input = new Input();
		List<String> inputTxt = input.read();

		int items = inputTxt.size();

		String allCombos = new String();
		List<String> scrambler = new ArrayList<String>();
		StringBuffer sbuf = new StringBuffer();

		int i = 0;
		int j = 1;
		int k = 1;
		int l = 0;

		String tempValueStorage;
		String tempValueStorage2;
		String currentEntry;
		String currentShift;
		String[] currentSplit;

		while (i < items) {
			currentEntry = inputTxt.get(i);
			allCombos += currentEntry + "\n";
			currentSplit = currentEntry.split(" ");
			currentShift = currentEntry;
			int currentLength = currentSplit.length;

			while (j < currentLength) {
				currentSplit = currentShift.split(" ");
				tempValueStorage = currentSplit[0];

				while (k < currentLength) {
					scrambler.add(currentSplit[k]);
					k++;
				}

				scrambler.add(tempValueStorage);

				while (l < currentLength) {
					tempValueStorage2 = scrambler.get(l);
					sbuf.append(tempValueStorage2 + " ");
					l++;
				}

				allCombos += sbuf + "\n";
				currentShift = sbuf.toString();
				currentShift = sbuf.toString();
				scrambler.clear();
				sbuf.delete(0, sbuf.length());
				j++;
				k = 1;
				l = 0;
			}
			i++;
			j = 1;
		}
		currentSplit = allCombos.split("\n");
		int splitSize = currentSplit.length;
		for (i = 0; i < splitSize; i++) {
			lines.add(currentSplit[i]);
		}

		return lines;
	}

}
