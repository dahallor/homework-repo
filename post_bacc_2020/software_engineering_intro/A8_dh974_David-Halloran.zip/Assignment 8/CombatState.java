
public interface CombatState {

	abstract Warrior fight(Warrior warriorOne, Warrior warriorTwo);

	abstract void nextState(CombatContext combatContext);

}
