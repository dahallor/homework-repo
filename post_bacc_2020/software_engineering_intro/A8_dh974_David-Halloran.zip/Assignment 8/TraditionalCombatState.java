
public class TraditionalCombatState implements CombatState {

	@Override
	public Warrior fight(Warrior warriorOne, Warrior warriorTwo) {
		Warrior winner;
		int attacker = warriorOne.calculateAttack();
		int defender = warriorTwo.calculateDefense();
		if (attacker > defender) {
			winner = warriorOne;
		} else {
			winner = warriorTwo;
		}
		return winner;
	}

	@Override
	public void nextState(CombatContext combatContext) {
		combatContext.setCombatState(new InverseCombatState());

	}
}
