
public class PowerCombatState implements CombatState {

	@Override
	public Warrior fight(Warrior warriorOne, Warrior warriorTwo) {
		Warrior winner;

		double attacker = warriorOne.calculatePower();
		double defender = warriorTwo.calculatePower();
		if (attacker > defender) {
			winner = warriorOne;
		} else {
			winner = warriorTwo;
		}

		return winner;
	}

	@Override
	public void nextState(CombatContext combatContext) {
		combatContext.setCombatState(new AttackCombatState());

	}

}
