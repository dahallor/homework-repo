
public class Main {

	public static void main(String[] args) {
		Warrior warriorOne = new AggressiveWarrior.Builder(1).attack(10).defense(10).build();
		Warrior warriorTwo = new DefensiveWarrior.Builder(6).attack(11).defense(17).build();
		Warrior winner;

		CombatContext combatContext = new CombatContext();
		combatContext.fight(warriorOne, warriorTwo);

	}
}
