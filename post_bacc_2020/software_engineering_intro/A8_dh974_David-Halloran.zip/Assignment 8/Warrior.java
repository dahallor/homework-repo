
public abstract class Warrior {

	int level;
	int attack;
	int defense;

	public Warrior() {

	}

	public int getLevel() {
		return level;
	}

	public int getAttack() {
		return attack;
	}

	public int getDefense() {
		return defense;
	}

	void calculate() {
		calculateAttack();
		calculateDefense();
		calculateBoost();
		calculatePower();
	}

	abstract int calculateAttack();

	abstract int calculateDefense();

	abstract double calculateBoost();

	double calculatePower() {
		double calcPower;
		calcPower = calculateAttack() + calculateDefense() + calculateBoost();
		return calcPower;
	}

	static abstract class WarriorBuilder {

		Warrior warrior;

		public WarriorBuilder attack(int attack) {
			warrior.attack = attack;
			return this;
		}

		public WarriorBuilder defense(int defense) {
			warrior.defense = defense;
			return this;
		}

		public Warrior build() {
			validate(warrior);
			return warrior;
		}

		public void validate(Warrior warrior) {

			if (warrior.level < 0 && warrior.attack < 0 && warrior.defense < 0) {
				throw new IllegalStateException(
						"Level must be greater than 0. Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (warrior.level < 0 && warrior.attack < 0 && warrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. Attack must be greater than 0. ");
			}
			if (warrior.level < 0 && warrior.attack > 0 && warrior.defense < 0) {
				throw new IllegalStateException("Level must be greater than 0. Defense must be greater than 0. ");
			}
			if (warrior.level > 0 && warrior.attack < 0 && warrior.defense < 0) {
				throw new IllegalStateException("Attack must be greater than 0. Defense must be greater than 0. ");
			}
			if (warrior.level < 0 && warrior.attack > 0 && warrior.defense > 0) {
				throw new IllegalStateException("Level must be greater than 0. ");
			}
			if (warrior.level > 0 && warrior.attack < 0 && warrior.defense > 0) {
				throw new IllegalStateException("Attack must be greater than 0. ");
			}
			if (warrior.level > 0 && warrior.attack > 0 && warrior.defense < 0) {
				throw new IllegalStateException("Defense must be greater than 0. ");
			}
		}
	}
}
