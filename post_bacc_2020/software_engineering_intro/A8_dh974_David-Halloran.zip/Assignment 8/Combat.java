
public class Combat {

	public Combat(CombatContext combatContext) {
		// TODO Auto-generated constructor stub
	}

	static Warrior duel(Warrior warriorOne, Warrior warriorTwo) {
		int oneWins = 0;
		int twoWins = 0;
		AttackCombatState attackCombatState = new AttackCombatState();
		DefenseCombatState defenseCombatState = new DefenseCombatState();
		PowerCombatState powerCombatState = new PowerCombatState();
		TraditionalCombatState traditionalCombatState = new TraditionalCombatState();
		InverseCombatState inverseCombatState = new InverseCombatState();
		if (attackCombatState.fight(warriorOne, warriorTwo) == warriorOne) {
			oneWins += 1;
			System.out.println("One Wins!");
		} else {
			twoWins += 1;
			System.out.println("Two Wins!");
		}
		if (defenseCombatState.fight(warriorOne, warriorTwo) == warriorOne) {
			oneWins += 1;
			System.out.println("One Wins!");
		} else {
			twoWins += 1;
			System.out.println("Two Wins!");
		}
		if (powerCombatState.fight(warriorOne, warriorTwo) == warriorOne) {
			oneWins += 1;
			System.out.println("One Wins!");
		} else {
			twoWins += 1;
			System.out.println("Two Wins!");
		}
		if (traditionalCombatState.fight(warriorOne, warriorTwo) == warriorOne) {
			oneWins += 1;
			System.out.println("One Wins!");
		} else {
			twoWins += 1;
			System.out.println("Two Wins!");
		}
		if (inverseCombatState.fight(warriorOne, warriorTwo) == warriorOne) {
			oneWins += 1;
			System.out.println("One Wins!");
		} else {
			twoWins += 1;
			System.out.println("Two Wins!");
		}
		System.out.println(" ");
		if (oneWins > twoWins) {
			return warriorOne;
		} else {
			return warriorTwo;
		}

	}
}
