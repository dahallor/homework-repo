
public class InverseCombatState implements CombatState {

	@Override
	public Warrior fight(Warrior warriorOne, Warrior warriorTwo) {
		Warrior winner;
		int attacker = warriorOne.calculateDefense();
		int defender = warriorTwo.calculateAttack();
		if (attacker >= defender) {
			winner = warriorOne;
		} else {
			winner = warriorTwo;
		}

		return winner;
	}

	@Override
	public void nextState(CombatContext combatContext) {
		// End of the line, no more state changes

	}
}
