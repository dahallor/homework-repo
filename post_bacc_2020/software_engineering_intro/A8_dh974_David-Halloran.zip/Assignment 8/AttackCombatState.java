
public class AttackCombatState implements CombatState {
	Warrior warrior;

	@Override
	public Warrior fight(Warrior warriorOne, Warrior warriorTwo) {
		Warrior winner;
		int attacker = warriorOne.calculateAttack();
		System.out.println(attacker);
		int defender = warriorTwo.calculateAttack();
		System.out.println(defender);
		if (attacker > defender) {
			winner = warriorOne;
		} else {
			winner = warriorTwo;
		}
		System.out.println("");
		return winner;
	}

	@Override
	public void nextState(CombatContext combatContext) {
		combatContext.setCombatState(new DefenseCombatState());

	}

}
