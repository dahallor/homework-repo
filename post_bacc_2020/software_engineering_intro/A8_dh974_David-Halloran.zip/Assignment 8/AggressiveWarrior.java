
public class AggressiveWarrior extends Warrior {

	public AggressiveWarrior(int level) {
		this.level = level;
	}

	@Override
	int calculateAttack() {
		int calcAttack;
		calcAttack = attack + (level * 2);
		return calcAttack;
	}

	@Override
	int calculateDefense() {
		int calcDefense;
		calcDefense = defense + level;
		return calcDefense;
	}

	@Override
	double calculateBoost() {
		double calcBoost;
		calcBoost = attack / 2.0;
		return calcBoost;
	}

	public static class Builder extends WarriorBuilder {
		AggressiveWarrior aggressiveWarrior;

		public Builder(int level) {
			aggressiveWarrior = new AggressiveWarrior(level);
			aggressiveWarrior.attack = 3;
			aggressiveWarrior.defense = 2;
		}

		@Override
		public Builder attack(int attack) {
			aggressiveWarrior.attack = attack;
			return this;
		}

		@Override
		public Builder defense(int defense) {
			aggressiveWarrior.defense = defense;
			return this;
		}

		@Override
		public Warrior build() {
			validate(aggressiveWarrior);
			return aggressiveWarrior;
		}

	}

}
