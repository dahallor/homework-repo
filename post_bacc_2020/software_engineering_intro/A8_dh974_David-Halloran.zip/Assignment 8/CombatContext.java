
public class CombatContext {
	private CombatState combatState;
	Warrior warriorOne;
	Warrior warriorTwo;

	CombatContext() {
		combatState = new PowerCombatState();
	}

	public void nextState(CombatContext combatContext) {
		combatState.fight(warriorOne, warriorTwo);
		combatState.nextState(this);
	}

	public CombatState getCombat() {
		return combatState;
	}

	public void setCombatState(CombatState combatState) {
		this.combatState = combatState;
	}

	public void fight(Warrior warriorOne, Warrior warriorTwo) {
		combatState.fight(warriorOne, warriorTwo);
		combatState.nextState(this);
	}

}
