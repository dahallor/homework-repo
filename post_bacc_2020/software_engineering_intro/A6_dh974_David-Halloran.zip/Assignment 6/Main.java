
public class Main {

	public static void main(String[] args) {
		Warrior warrior1 = new AggressiveWarrior.Builder(1).attack(10).defense(10).build();
		System.out.println("Aggresive: " + warrior1.level + " " + warrior1.attack + " " + warrior1.defense);
		System.out.println("Attack: " + warrior1.calculateAttack());
		System.out.println("Defense: " + warrior1.calculateDefense());
		System.out.println("Boost: " + warrior1.calculateBoost());
		System.out.println("Power: " + warrior1.calculatePower());
		Warrior warrior2 = new DefensiveWarrior.Builder(6).attack(11).defense(17).build();
		System.out.println("Defensive: " + warrior2.level + " " + warrior2.attack + " " + warrior2.defense);
		System.out.println("Attack: " + warrior2.calculateAttack());
		System.out.println("Defense: " + warrior2.calculateDefense());
		System.out.println("Boost: " + warrior2.calculateBoost());
		System.out.println("Power: " + warrior2.calculatePower());
	}
}
