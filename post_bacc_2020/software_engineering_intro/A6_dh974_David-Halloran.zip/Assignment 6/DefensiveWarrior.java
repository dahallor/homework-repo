
public class DefensiveWarrior extends Warrior {

	static Warrior warrior;

	public DefensiveWarrior(int level) {
		this.level = level;
	}

	@Override
	int calculateAttack() {
		int calcAttack;
		calcAttack = attack + level;
		return calcAttack;
	}

	@Override
	int calculateDefense() {
		int calcDefense;
		calcDefense = defense + (2 * level);
		return calcDefense;
	}

	@Override
	double calculateBoost() {
		double calcBoost;
		calcBoost = defense / 2.0;
		return calcBoost;
	}

	public static class Builder extends WarriorBuilder {
		DefensiveWarrior defensiveWarrior;

		public Builder(int level) {
			defensiveWarrior = new DefensiveWarrior(level);
			defensiveWarrior.attack = 2;
			defensiveWarrior.defense = 3;
		}

		@Override
		public Builder attack(int attack) {
			defensiveWarrior.attack = attack;
			return this;
		}

		@Override
		public Builder defense(int defense) {
			defensiveWarrior.defense = defense;
			return this;
		}

		@Override
		public Warrior build() {
			validate(defensiveWarrior);
			return defensiveWarrior;
		}

	}

}
