import java.io.IOException;
import java.util.List;

public class MasterControl {

	@SuppressWarnings("null")
	public static void main(String[] args) throws IOException {
		MasterControl masterControl = new MasterControl();
		masterControl.start(ScannerWrapper.getInstance(), SystemWrapper.getInstance());

	}

	@SuppressWarnings("null")
	public void start(ScannerWrapper scannerwrapper, SystemWrapper systemwrapper) throws IOException {
		List<String> inputResults;
		List<String> shifterResults;
		List<String> alphabetResults;

		Input input = new Input();
		CircularShifter shift = new CircularShifter();
		Alphabetizer abc = new Alphabetizer();
		Output output = new Output();

		inputResults = input.read(scannerwrapper, systemwrapper);
		shifterResults = shift.shiftLines(inputResults);
		alphabetResults = abc.sort(shifterResults);
		output.write(alphabetResults, systemwrapper);

	}

}
