import java.io.IOException;

public class SystemWrapper {
	private static SystemWrapper systemwrapper = new SystemWrapper();

	private SystemWrapper() {

	}

	public static SystemWrapper getInstance() throws IOException {

		return systemwrapper;
	}

	void println(String output) {
		System.out.println(output);

	}

}
