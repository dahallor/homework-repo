import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Output {

	public void write(List<String> lines, SystemWrapper systemWrapper) throws IOException {
		String output;
		Alphabetizer sortedResults = new Alphabetizer();
		List<String> alphabetizerResults = new ArrayList<String>();

		alphabetizerResults = sortedResults.sort(lines);
		int size = alphabetizerResults.size();
		for (int i = 0; i < size; i++) {
			output = alphabetizerResults.get(i);
			systemWrapper.println(output);
		}

	}

}
