import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScannerWrapper {
	private static ScannerWrapper scannerwrapper = new ScannerWrapper();

	private ScannerWrapper() {

	}

	static List<String> txtInput = new ArrayList<String>();

	public static ScannerWrapper getInstance() throws IOException {
		System.out.println("Hello, please enter lines to add. Enter -1 to quit");

		return scannerwrapper;
	}

	public static String nextLine() {
		Scanner scan = new Scanner(System.in);
		String input = "";
		int numInput = 0;

		while (true) {
			if (scan.hasNextInt()) {
				numInput = scan.nextInt();
			}
			if (scan.hasNextLine()) {
				input = scan.nextLine();
				ScannerWrapper.setSavedList(input);
			}
			if (numInput == -1) {
				break;
			}
		}
		scan.close();
		return null;
	}

	private static void setSavedList(String input) {
		txtInput.add(input);
	}

	public static List<String> getSavedList() {
		return txtInput;

	}
}
