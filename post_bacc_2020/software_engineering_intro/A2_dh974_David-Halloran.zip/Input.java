import java.io.IOException;
import java.util.List;

public class Input {

	public List<String> txtList;
	public String txtString;

	@SuppressWarnings("null")
	public List<String> read(ScannerWrapper scannerWrapper, SystemWrapper systemwrapper) throws IOException {

		txtString = ScannerWrapper.nextLine();
		txtList = ScannerWrapper.getSavedList();

		return txtList;
	}

}
