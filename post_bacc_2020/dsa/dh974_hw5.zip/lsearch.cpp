#include <iostream>


using namespace std;

int main()
{
    char text[] = " !.abcdefghijklmnopjrstuvwxyz";
    string answer;
    string word;
    string x;
    int i = 0;

    cout << "Hello! please type either 'y' or 'n' to answer the prompt to spell you your desired word. Enter 'y' at '!' prompt to exit" << endl;

    while(true){
        cout << "Are you thinking of the letter '";
        cout << text[i];
        cout <<"'?" << endl;
        cin >> answer;

        x = text[i];
        if(x == "!" && answer == "y"){
            break;
            }

        if(answer == "y"){
            word += text[i];
            i = 0;
            continue;
        }

        if(i < 29){
            i++;
        }

        if(i == 29){
            i = 0;
        }

    }
    cout << "You entered: " + word << endl;
    return 0;
}