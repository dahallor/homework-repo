#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

int main()
{
    string original = " !.abcdefghijklmnopqrstuvwxyz";
    string text = " !.abcdefghijklmnopqrstuvwxyz";


    int start = 0;
    int stop = 28;
    int pivot = stop/2;
    int index;
    int i = 0;

    string x;
    string y;
    string z;
    string answer;
    string word;

    cout << "Hello! please type either 'y' or 'n' to answer the prompt to spell you your desired word. Enter 'y' at '!' prompt to exit" << endl;

    while(true){
        cout << "Is your letter between '";
        cout << text[start];
        cout << "' and '";
        cout << text[pivot];
        cout <<"'? (y/n)" << endl;
        cin >> answer;

        x = text[start];
        y = text[pivot];


        if(answer == "y"){
            if(x != y){
                text = text.substr(start, pivot);
                cout << text << endl;
                pivot /= 2;
                i += 1;
                continue;
            }
            if(x == y){
                cout << "Is your letter '";
                cout << text;
                cout << "'? (y/n)";
                cin >> answer;
                if(answer == "y"){
                    if(x != "!"){
                        word += x;
                    }
                    if(x == "!"){
                    i += 1;
                    break;
                    }
                }
                text = original;
                start = 0;
                stop = 28;
                pivot = stop/2;
                i += 1;
                continue;
            }
        }
        if(answer =="n"){
            if(x != y){
                text = text.substr(pivot+1);
                stop = text.size();
                pivot = (stop-start)/2;
                i += 1;
                continue;
            }
            if(x == y){
                index = original.find(x);
                index += 1;
                cout << "Is your letter '";
                cout << original[index];
                cout << "'? (y/n)";
                cin >> answer;
                if(answer == "y"){
                    z = original[index];
                    if(z != "!"){
                        word += z;
                    }
                    if(z == "!"){
                        break;
                    }
                }
                text = original;
                start = 0;
                stop = 28;
                pivot = stop/2;
                i += 1;
                continue;

            }

        }
    }
    cout << "Your word is: " + word << endl;
    cout << i << endl;
}
