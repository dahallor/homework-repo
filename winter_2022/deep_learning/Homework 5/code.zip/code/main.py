
import numpy
from act_func import *
from objective_func import *
from section2 import *
from section3 import *
from section4 import *
from ADAM import *
from fully_connect import FullyConnectedLayer
from input import *
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d
import sys
import pdb
import math




if __name__ == '__main__':
    numpy.set_printoptions(threshold=sys.maxsize)

    #multiclass()

    #ANN()

    #MLP()


    




    
    




        
        










    







