test_string = "12345|1234 |12345"
print(len(test_string))
print(test_string[10])